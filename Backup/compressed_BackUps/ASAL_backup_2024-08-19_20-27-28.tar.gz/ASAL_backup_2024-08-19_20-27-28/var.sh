DATE=$(date)
echo $DATE
